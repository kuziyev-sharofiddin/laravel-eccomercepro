<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style type="text/css">
        .div_center
        {
            text-align: center;
            padding-top: 40px;
        }
        .h2_font
        {
            font-size: 40px;
            padding-bottom: 40px;
        }
        .input_color
        {
            color: black;
        }
        .center
        {
            margin: auto;
            width: 50%;
            text-align: center;
            margin-top: 40px;
            border: 3px solid white;
        }
        .font_size
        {
            text-align: center;
            font-size: 40px;
            padding-top: 20px;        }
        .th_color
        {
            background: skyblue;
        }
        .th_dag
        {
            padding: 30px;
        }
    </style>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <h2 class="font_size">All Products</h2>
                <table class="center">
                    <tr class="th_color">
                        <th class="th_dag">Id</th>
                        <th class="th_dag">Product Title</th>
                        <th class="th_dag">Description</th>
                        <th class="th_dag">Quantity</th>
                        <th class="th_dag">Category</th>
                        <th class="th_dag">Price</th>
                        <th class="th_dag">Discount Price</th>
                        <th class="th_dag">Product Image</th>
                        <th class="th_dag">Action</th>
                    </tr>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->title); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td><?php echo e($product->category->category_name); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->discount_price); ?></td>
                        <td>
                            <img style="width: 150px; height:150px;" class="top" src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="">
                        </td>
                        <td>
                            <form action="<?php echo e(route('products.destroy', ['product'=>$product->id])); ?>" method="POST" onsubmit="return confirm('Are you sure to delete this?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            <button  type="submit"><i class="fa fa-trash-o" style="padding-top:20px;font-size:48px; color:red"></i></button>
                            </form>
                            <a href="<?php echo e(route('products.edit', ['product'=>$product->id])); ?>"><i class="fa fa-edit" style="padding-top:20px;font-size:48px;"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html>

<?php /**PATH C:\OSPanel\domains\eccomerce-pro\resources\views/admin/show_products.blade.php ENDPATH**/ ?>