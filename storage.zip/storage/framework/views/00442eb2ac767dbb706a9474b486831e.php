<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style type="text/css">
        .div_center
        {
            text-align: center;
            padding-top: 40px;
        }
        .h2_font
        {
            font-size: 40px;
            padding-bottom: 40px;
        }
        .input_color
        {
            color: black;
        }
        .center
        {
            margin: auto;
            width: 50%;
            text-align: center;
            margin-top: 40px;
            border: 3px solid white;
        }
        .font_size
        {
            text-align: center;
            font-size: 40px;
            padding-top: 20px;        }
        .th_color
        {
            background: skyblue;
        }
        .th_dag
        {
            padding: 30px;
        }
    </style>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <h2 class="font_size">All Contacts</h2>
                <table class="center">
                    <tr class="th_color">
                        <th class="th_dag">Id</th>
                        <th class="th_dag">Name</th>
                        <th class="th_dag">Email</th>
                        <th class="th_dag">Phone</th>
                        <th class="th_dag">Description</th>
                        <th class="th_dag">Created At</th>
                        <th class="th_dag">Action</th>
                    </tr>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($contact->id); ?></td>
                        <td><?php echo e($contact->name); ?></td>
                        <td><?php echo e($contact->email); ?></td>
                        <td><?php echo e($contact->phone); ?></td>
                        <td><?php echo e($contact->description); ?></td>
                        <td><?php echo e($contact->created_at); ?></td>

                        <td>
                            <form action="<?php echo e(route('contact_destroy', ['contact'=>$contact->id])); ?>" method="POST" onsubmit="return confirm('Are you sure to delete this?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            <button  type="submit"><i class="fa fa-trash-o" style="padding-top:20px;font-size:48px; color:red"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html>

<?php /**PATH C:\OSPanel\domains\eccomerce-pro\resources\views/admin/contact.blade.php ENDPATH**/ ?>