<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style type="text/css">
        .div_center
        {
            text-align: center;
            padding-top: 40px;
        }
        .h2_font
        {
            font-size: 40px;
            padding-bottom: 40px;
        }
        .input_color
        {
            color: black;
        }
        .center
        {
            margin: auto;
            width: 50%;
            text-align: center;
            margin-top: 30px;
            border: 3px solid white;
        }
        label
        {
            display: inline-block;
            width: 200px;
        }

        .div_design
        {
            padding-bottom: 15px;
        }
    </style>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                
                <div class="div_center">
                    <h2 class="h2_font">
                        Add Product
                    </h2>
                    <form action="<?php echo e(route('products.update', ['product'=>$product->id])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="div_design">
                        <label for="">Product Title:</label>
                        <input type="text" class="input_color" value="<?php echo e($product->title); ?>" name="title" placeholder="Write product title">
                        </div>
                        <div class="div_design">
                        <label for="">Product Description:</label>
                        <input type="text" class="input_color" value="<?php echo e($product->description); ?>" name="description" placeholder="Write product description">
                        </div>
                        <div class="div_design">
                        <label for="">Product Price:</label>
                        <input type="number" class="input_color" value="<?php echo e($product->price); ?>" name="price" placeholder="Write product price">
                        </div>
                        <div class="div_design">
                        <label for="">Discount Price:</label>
                        <input type="number" class="input_color" value="<?php echo e($product->discount_price); ?>" name="discount_price" placeholder="Write product discount_price">
                        </div>
                        <div class="div_design">
                        <label for="">Product Quantity:</label>
                        <input type="number" class="input_color" value="<?php echo e($product->quantity); ?>" name="quantity" placeholder="Write product quantity">
                        </div>
                        <div class="div_design">
                        <label for="">Select Product Category:</label>
                        <select style="color:black" name="category_id">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                        <div class="div_design">
                        <label for="">Product Image:</label>
                        <input type="file" class="input_color" name="image">
                        </div>
                        <div class="div_design">
                        <input type="submit" class="btn btn-primary" name="submit" value="Add Product">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html>
<?php /**PATH C:\OSPanel\domains\eccomerce-pro\resources\views/admin/edit_product.blade.php ENDPATH**/ ?>