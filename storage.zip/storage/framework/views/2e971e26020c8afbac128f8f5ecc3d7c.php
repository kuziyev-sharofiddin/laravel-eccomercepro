<section class="product_section layout_padding">
    <div class="container">
       <div class="heading_container heading_center">

          <div>
            <form action="<?php echo e(route('search_product')); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <input style="width: 500px;" type="text" name="search" placeholder="Search For Something">
                <input type="submit" value="search">
            </form>
          </div>
       </div>
       <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                        <?php echo e(session()->get('message')); ?>

                    </div>
        <?php endif; ?>
       <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-6 col-md-4 col-lg-4">
             <div class="box">
                <div class="option_container">
                   <div class="options">
                      <a href="<?php echo e(route('product_details', ['product'=>$product->id])); ?>" class="option1">
                      Product Details
                      </a>
                      <form action="<?php echo e(route('add_cart', ['product'=>$product->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4">
                                <input type="number" name="quantity" value="1" min="1" style="width: 100px">
                            </div>
                            <div class="col-md-4">
                                <input type="submit" value="Add to Cart">
                            </div>
                        </div>
                      </form>
                   </div>
                </div>
                <div class="img-box">
                   <img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="">
                </div>
                <div class="detail-box">
                   <h5>
                      <?php echo e($product->title); ?>

                   </h5>
                   <?php if($product->discount_price!=null): ?>
                    <h6 style="color: red">
                        Discount price
                        <br>
                    $<?php echo e($product->discount_price); ?>

                    </h6>
                    <h6 style="text-decoration: line-through; color:blue">
                        Price
                        <br>
                        $<?php echo e($product->price); ?>

                     </h6>
                     <?php else: ?>
                   <h6 style="color: blue">
                      $<?php echo e($product->price); ?>

                   </h6>
                   <?php endif; ?>
                </div>
             </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($products->links()); ?>

       </div>
    </div>
 </section>
<?php /**PATH C:\OSPanel\domains\eccomerce-pro\resources\views/home/product_view.blade.php ENDPATH**/ ?>