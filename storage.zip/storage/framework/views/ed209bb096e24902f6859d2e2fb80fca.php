<!DOCTYPE html>
<html>
   <head>
      <base href="/public">
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="home/images/favicon.png" type="">
      <title>Famms - Fashion HTML Template</title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="home/css/bootstrap.css" />
      <!-- font awesome style -->
      <link href="home/css/font-awesome.min.css" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="home/css/style.css" rel="stylesheet" />
      <!-- responsive style -->
      <link href="home/css/responsive.css" rel="stylesheet" />
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js" integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   </head>
   <body>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="hero_area">
         <!-- header section strats -->
         <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- end header section -->
      <!-- product section -->
      <section class="product_section layout_padding">
        <div class="container">
           <div class="heading_container heading_center">

              <div>
                <form action="<?php echo e(route('search_product')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <input style="width: 500px;" type="text" name="search" placeholder="Search For Something">
                    <input type="submit" value="search">
                </form>
              </div>
           </div>
           <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php echo e(session()->get('message')); ?>

                        </div>
            <?php endif; ?>
           <div class="row">
            <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-6 col-md-4 col-lg-4">
                 <div class="box">
                    <div class="option_container">
                       <div class="options">
                          <a href="<?php echo e(route('product_details', ['product'=>$product->id])); ?>" class="option1">
                          Product Details
                          </a>
                          <form action="<?php echo e(route('add_cart', ['product'=>$product->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-4">
                                    <input type="number" name="quantity" value="1" min="1" style="width: 100px">
                                </div>
                                <div class="col-md-4">
                                    <input type="submit" value="Add to Cart">
                                </div>
                            </div>
                          </form>
                       </div>
                    </div>
                    <div class="img-box">
                       <img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="">
                    </div>
                    <div class="detail-box">
                       <h5>
                          <?php echo e($product->title); ?>

                       </h5>
                       <?php if($product->discount_price!=null): ?>
                        <h6 style="color: red">
                            Discount price
                            <br>
                        $<?php echo e($product->discount_price); ?>

                        </h6>
                        <h6 style="text-decoration: line-through; color:blue">
                            Price
                            <br>
                            $<?php echo e($product->price); ?>

                         </h6>
                         <?php else: ?>
                       <h6 style="color: blue">
                          $<?php echo e($product->price); ?>

                       </h6>
                       <?php endif; ?>
                    </div>
                 </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
        </div>
     </section>

      <!-- end product section -->
     <!--  Comment section -->
     <div style="text-align: center; padding-bottom:30px;">
        <h1 style="font-size: 30px; text-align:center; padding-top: 20px; padding-bottom: 20px;">
            Comments
        </h1>
        <form action="<?php echo e(route('add_comment')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <textarea style="height: 150px; width: 600px;" placeholder="Comment something here..." name="comment"></textarea>
            <br>
            <input class="btn btn-primary" type="submit">
        </form>
     </div>
     <div style="padding-left: 20%;">
        <h1 style="font-size: 20px; padding-bottom: 20px;">
            All Comments
        </h1>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <b><?php echo e($comment->name); ?></b>
                <p><?php echo e($comment->comment); ?></p>
                <a class="btn btn-primary" href="javascript::void(0);" data-Commentid="<?php echo e($comment->id); ?>" onclick="reply(this)">Reply</a>
                    <?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($reply->comment_id==$comment->id): ?>
                        <div style="padding-left: 3%; padding-bottom: 10px;">
                            <b><?php echo e($reply->name); ?></b>
                            <p><?php echo e($reply->reply); ?></p>
                            <a class="btn btn-warning" href="javascript::void(0);" data-Commentid="<?php echo e($comment->id); ?>" onclick="reply(this)">Reply</a>
                        </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div style="display: none;" class="replyDiv">
        <form action="<?php echo e(route('add_reply')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" id="commentId" name="commentId" hidden>
            <textarea placeholder="Write something here..." name="reply" style="height: 100px; width: 500px;"></textarea>
            <br>
            <button type="submit" class="btn btn-warning">Reply</button>
            <a href="javascript::void(0);" class="btn btn-secondary" onclick="reply_close(this)">Close</a>
        </form>
         </div>


     </div>

      <!-- end Comment section -->
      <div class="cpy_">
         <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>

            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>

         </p>
      </div>
      <script type="text/javascript">
        function reply(caller){
            document.getElementById('commentId').value=$(caller).attr('data-Commentid');
            $(' .replyDiv').insertAfter($(caller));
            $(' .replyDiv').show();
        }

        function reply_close(caller){
            $(' .replyDiv').hide();
        }


      </script>
      <script>
        document.addEventListener("DOMContentLoaded", function(event) {
            var scrollpos = localStorage.getItem('scrollpos');
            if (scrollpos) window.scrollTo(0, scrollpos);
        });

        window.onbeforeunload = function(e) {
            localStorage.setItem('scrollpos', window.scrollY);
        };
    </script>
      <!-- jQery -->
      <script src="home/js/jquery-3.4.1.min.js"></script>
      <!-- popper js -->
      <script src="home/js/popper.min.js"></script>
      <!-- bootstrap js -->
      <script src="home/js/bootstrap.js"></script>
      <!-- custom js -->
      <script src="home/js/custom.js"></script>
   </body>
</html>
<?php /**PATH C:\OSPanel\domains\eccomerce-pro\resources\views/home/product_category.blade.php ENDPATH**/ ?>