<header class="header_section">
            <div class="container">
               <nav class="navbar navbar-expand-lg custom_nav-container ">
                  <a class="navbar-brand" href="index.html"><img width="250" src="home/images/logo.png" alt="#" /></a>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class=""> </span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                     <ul class="navbar-nav">
                        <li class="nav-item active">
                           <a class="nav-link" href="\">Home <span class="sr-only">(current)</span></a>
                        </li>
                       <li class="nav-item dropdown">
                           <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">Category<span class="caret"></span></a>
                           <ul class="dropdown-menu">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><a href="<?php echo e(route('product_category', ['category' => $category->id])); ?>"><?php echo e($category->category_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </ul>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="<?php echo e(route('productss')); ?>">Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
                         </li>
                         <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('show_cart')); ?>">Cart</a>
                         </li>
                         <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('show_order')); ?>">Order</a>
                         </li>
                         <form class="form-inline" style="margin-right:70px;">
                            <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit">
                            <i class="fa fa-search" aria-hidden="true"></i>
                            </button>
                         </form>
                        <?php if( Route::has('login') ): ?>
                         <?php if(auth()->guard()->check()): ?>
                         <li class="nav-item">
                           <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
                         </li><br><br>
                         <?php else: ?>
                         <li class="nav-item">
                            <a class="btn btn-primary" style="margin-right:10px;" href="<?php echo e(route('login')); ?>">Login</a>
                         </li><br><br>
                         <li class="nav-item">
                            <a class="btn btn-success" href="<?php echo e(route('register')); ?>">Register</a>
                         </li>
                         <?php endif; ?>
                         <?php endif; ?>
                     </ul>
                  </div>
               </nav>
            </div>
</header>
<?php /**PATH C:\OSPanel\domains\eccomerce-pro\resources\views/home/header.blade.php ENDPATH**/ ?>